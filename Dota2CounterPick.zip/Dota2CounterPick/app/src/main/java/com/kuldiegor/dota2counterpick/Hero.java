package com.kuldiegor;

import java.util.ArrayList;

/**
 * Created by aeterneus on 22.07.2016.
 */
public class Hero {
    public String Name;
    public ArrayList<Hero> Strong;
    public ArrayList<Hero> Weak;
    public Hero(String name){
        Name = name;
        Strong = new ArrayList<Hero>();
        Weak = new ArrayList<Hero>();
    }
}
