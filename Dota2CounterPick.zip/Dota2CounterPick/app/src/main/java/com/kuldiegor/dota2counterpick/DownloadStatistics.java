package com.kuldiegor.dota2counterpick;

import android.widget.ProgressBar;
import android.widget.TextView;

import com.kuldiegor.StringTool;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by aeterneus on 16.09.2016.
 */
public class DownloadStatistics {
    public ArrayList<String> data;
    private TextView textView;
    private ProgressBar progressBar;
    private String getHTML(String urlToRead) {
        URL url;
        HttpURLConnection conn;
        BufferedReader rd;
        String line;
        StringBuilder result = new StringBuilder();
        try {
            url = new URL(urlToRead);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("User-Agent","Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.101 Safari/537.36 OPR/40.0.2308.52 (Edition beta)");
            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            while ((line = rd.readLine()) != null) {
                result.append(line);
            }
            rd.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result.toString();
    }
    private String parseperson(String text){
        StringBuilder result = new StringBuilder();
        int i=0;
        int p=0;
        String s="";
        do {
            i = text.indexOf("<tr data-link-to=\"&#47;heroes&#47;",p);
            if (i>-1){
                int en = text.indexOf("\"",i+34);
                //en = en-i-34;
                s = text.substring(i+34,en);
                p = en;
            } else {
                s = "";
            }
            if (s!=""){
                result.append(s);
                result.append(",");
            }

        } while (s!="");


        return result.toString();
    }
    DownloadStatistics(ArrayList<String> Urls, final TextView textView, final ProgressBar progressBar){
        data = new ArrayList<>();
        this.textView = textView;
        this.progressBar = progressBar;
        final int size = Urls.size();
        textView.post(new Runnable() {
            @Override
            public void run() {
             textView.setText("0/"+Integer.toString(size));
            }
        });
        progressBar.post(new Runnable() {
            @Override
            public void run() {
                progressBar.setMax(size);
            }
        });
        for (int i=0;i<Urls.size();i++){
            String html = getHTML(Urls.get(i));
            String str = StringTool.parse(html,"<section><header>Силён против","</section>");
            str = StringTool.parse(str,"<tbody>","</tbody>");
            String stroka = "\""+parseperson(str)+"\"";
            str = StringTool.parse(html,"<section><header>Слаб против","</section>");
            str = StringTool.parse(str,"<tbody>","</tbody>");
            stroka += "("+parseperson(str)+")";
            data.add(StringTool.parse(Urls.get(i),"https://ru.dotabuff.com/heroes/","")+':'+stroka);
            final int ind = i+1;
            textView.post(new Runnable() {
                @Override
                public void run() {
                    textView.setText(ind+"/"+size);
                }
            });
            progressBar.post(new Runnable() {
                @Override
                public void run() {
                    progressBar.setProgress(ind);
                }
            });
        }
    }
}
