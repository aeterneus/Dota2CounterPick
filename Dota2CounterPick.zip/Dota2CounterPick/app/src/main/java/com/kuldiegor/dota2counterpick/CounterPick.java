package com.kuldiegor.dota2counterpick;

import com.kuldiegor.Hero;
import com.kuldiegor.StringTool;


import java.util.*;

/**
 * Created by aeterneus on 05.09.2016.
 */
public class CounterPick {
    private ArrayList<Hero> AllHero;
    private ArrayList<String> HeroesName;
    //public CounterPick(){}
    public CounterPick(ArrayList<String> lines){
        //Загрузка сырых данных вида (<имя персонажа>:"<силен против>"(<слаб против>))
        AllHero = new ArrayList<>();
        HeroesName = new ArrayList<>();
        for (int i=0;i<lines.size();i++){
            //Создаем список героев только с именами, это необходимо что-бы сразу затем ссылаться на объект Hero
            Hero hero = new Hero(StringTool.parse(lines.get(i),"",":"));
            HeroesName.add(hero.Name);
            AllHero.add(hero);
        }

        for (int i=0;i<lines.size();i++){
            //Проходимся по списку и парсим данные добавляя не просто имена а именно ссылки на объект
            Hero hero = AllHero.get(i);
            String str = StringTool.parse(lines.get(i),"\"","\"");
            String[] mas = str.split(",");
            for (int j=0;j<mas.length;j++) {
                hero.Strong.add(AllHero.get(HeroesName.indexOf(mas[j])));
            }
            str = StringTool.parse(lines.get(i),"(",")");
            mas = str.split(",");
            for (int j=0;j<mas.length;j++) {
                hero.Weak.add(AllHero.get(HeroesName.indexOf(mas[j])));
            }

        }
    }
    public void setAllHero(ArrayList<Hero> allHero){
        //Если конструктор вызвали без параметров то необходимо вызывать этот метод
        // для инициализации всех героев
        AllHero = new ArrayList<>(allHero);
    }
    public ArrayList<Hero> getHeroesFromNames(ArrayList<String> names){
        //Получение списка героев по их именам
        ArrayList<Hero> result = new ArrayList<>();
        for (int i=0;i<names.size();i++){
            result.add(AllHero.get(HeroesName.indexOf(names.get(i))));
        }
        return result;
    }
    public Hero getHeroFromName(String name){
        return AllHero.get(HeroesName.indexOf(name));
    }
    public Hero getHero(int i){
        return AllHero.get(i);
    }
    public ArrayList<String> CalculateCounterPick(ArrayList<Hero> Heroes){
//        Подсчет контрпика с сортировкой по количеству контр персонажей

        class Her{
            public String Name;
            public int Count;
            public Her(String name,int count)
            {
                Name = name;
                Count = count;
            }
        }
        ArrayList<String> Result = new ArrayList<>();
        HashMap<String,Integer> Re = new HashMap<>();
//        Пробегаемся по входному списку героев и добавляем всех против кого входные герои слабы
        for (Hero h:Heroes){
            for (Hero h2:h.Weak){
                if (Re.containsKey(h2.Name)) {
                    Re.put(h2.Name, Re.get(h2.Name) + 1);
                } else {
                    Re.put(h2.Name, 1);
                }
            }

        }
//        Удаляем колизии а так же если есть имя входного героя
        for (Hero h:Heroes){
            for (Hero h2:h.Strong){
                Re.put(h2.Name,0);
            }
            Re.put(h.Name,0);
        }
//Для сортировки создадим небольшой класс с указанием количества контр персонажей
        ArrayList<Her> ListHer = new ArrayList<>();
        for (Map.Entry entry : Re.entrySet()) {
            if ((Integer)entry.getValue() > 0) {
                ListHer.add(new Her((String) entry.getKey(), (Integer)entry.getValue()));
            }
        }
//        Сортируем наш список
        Collections.sort(ListHer, new Comparator<Her>() {
            @Override
            public int compare(Her o1, Her o2) {
                return o2.Count-o1.Count;
            }
        });
        for (Her h:ListHer){
            Result.add(h.Name);
        }
        return Result;
    }
    public ArrayList<String> CalculateCounterPick2(ArrayList<Hero> Heroes){
//        Подсчет контр пика с сортировкой по уровню преимущества
        ArrayList<String> Result = new ArrayList<>();
        int n = Heroes.get(0).Weak.size();
//        Добавлять данные надо по особому
        /*Сначало идут первые строчки всех входных героев, затем вторые и так далее*/
        for (int i=0;i<n;i++){
            for (int j=0;j<Heroes.size();j++){
                if (!Result.contains(Heroes.get(j).Weak.get(i).Name)) {
                    Result.add(Heroes.get(j).Weak.get(i).Name);
                }
            }
        }
//        Удаляем колизии а так же если есть имя входного героя
        for (Hero h:Heroes){
            for (Hero h2:h.Strong){
                Result.remove(h2.Name);
            }
            Result.remove(h.Name);
        }

        return Result;
    }
    public ArrayList<String> getHeroesName(){
        return new ArrayList<>(HeroesName);
    }

}
