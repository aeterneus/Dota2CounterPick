package com.kuldiegor;

/**
 * Created by aeterneus on 07.01.2017.
 */
public class IntBox {
    public int offset=0;
    public IntBox(int off){
        this.offset = off;
    }
}
