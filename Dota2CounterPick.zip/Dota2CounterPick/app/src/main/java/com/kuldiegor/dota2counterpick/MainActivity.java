package com.kuldiegor.dota2counterpick;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.net.DhcpInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import com.kuldiegor.StringTool;
import com.kuldiegor.dota2counterpick.CounterPick;
import com.kuldiegor.Hero;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    final String TAG = "myLogs";
    public Spinner spinner;
    public Spinner spinner2;
    public Spinner spinner3;
    public Spinner spinner4;
    public Spinner spinner5;
    public ListView listView;
    private Socket client;
    public EditText editText;
    public TextView textView;
    public TextView textView2;
    public DataOutputStream dataOutputStream= null;
    public DataInputStream dataInputStream = null;
    String ip="192.168.0.80";
    int port=6000;
    private Boolean isReading=false;
    /*public static ArrayList<Hero> AllHero = new ArrayList<Hero>();*/
    public ArrayList<String> HeroesName;/* = new ArrayList<String>();*/
    public CounterPick counterPick;
    int MethodSortirovki = 0;
    public static final String APP_PREFERENCES = "mysettings";
    public static final String APP_PREFERENCES_UPDATE = "lastupdate";
    final String FILENAME = "filestatistics";
    private SharedPreferences mSettings;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        if (mSettings==null){
            mSettings = getSharedPreferences(APP_PREFERENCES, Context.MODE_PRIVATE);
        }
        if (!mSettings.contains(APP_PREFERENCES_UPDATE)) {
            menu.getItem(1).setTitle("база:сильно устарела!");
        } else {
            menu.getItem(1).setTitle("база:"+(new SimpleDateFormat()).format(new Date(mSettings.getLong(APP_PREFERENCES_UPDATE, 0))));
        }
        //menu.getItem(1).setTitle("база");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.action_settings:
                Intent intent = new Intent(MainActivity.this, Main2Activity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    public void writeFile(ArrayList<String> strings) {
        try {
            // отрываем поток для записи
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(
                    openFileOutput(FILENAME, MODE_PRIVATE)));
            // пишем данные
            for (int i=0;i<strings.size();i++){
                bw.write(strings.get(i)+"\n");
            }
            //bw.write("Содержимое файла");
            // закрываем поток
            bw.close();
           // Log.d(LOG_TAG, "Файл записан");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void readFile(ArrayList<String> strings) {
        try {
            // открываем поток для чтения
            BufferedReader br = new BufferedReader(new InputStreamReader(
                    openFileInput(FILENAME)));
            String str = "";
            // читаем содержимое
            while ((str = br.readLine()) != null) {
                //Log.d(LOG_TAG, str);
                strings.add(str);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Resources r = this.getResources();
        InputStream is = r.openRawResource(R.raw.statitic);
        BufferedReader reader = null;
        editText = (EditText) findViewById(R.id.editText);
        textView = (TextView) findViewById(R.id.textView);
       // textView2 = (TextView) findViewById(R.id.textView2);
        ArrayList<String> lines = new ArrayList<String>();
        mSettings = getSharedPreferences(APP_PREFERENCES, Context.MODE_PRIVATE);

            // Получаем число из настроек
//             = mSettings.getLong(APP_PREFERENCES_UPDATE, 0);
            // Выводим на экран данные из настроек

        //lines.add("");
    if (!mSettings.contains(APP_PREFERENCES_UPDATE)) {
        try {
            reader = new BufferedReader(
                    new InputStreamReader(is));
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
        } catch (Exception e) {
        }
        //MenuItem menuItem = (MenuItem)findViewById(R.id.text_date_update);
       // menuItem.setTitle("Статистика:сильно устарела");
        writeFile(lines);
        SharedPreferences.Editor editor = mSettings.edit();
        editor.putLong(APP_PREFERENCES_UPDATE, (new Date()).getTime());
        editor.apply();
    } else {
        //MenuItem menuItem = (MenuItem)findViewById(R.id.text_date_update);
       // menuItem.setTitle("Статистика:"+mSettings.getLong(APP_PREFERENCES_UPDATE, 0));
        readFile(lines);
    }
        counterPick = new CounterPick(lines);
        /*//Создаем список героев только с именами, это необходимо что-бы сразу затем ссылаться на объект Hero
        for (int i=0;i<lines.size();i++){
            Hero hero = new Hero(StrTool.Parse(lines.get(i),"",":",0));
//            HeroesName[i] = hero.Name;
            HeroesName.add(hero.Name);
            AllHero.add(hero);
        }

        //Проходимся по списку и парсим данные добавляя не просто имена а именно ссылки на объект
        for (int i=0;i<lines.size();i++){
            Hero hero = AllHero.get(i);
            String str = StrTool.Parse(lines.get(i),"\"","\"",0);
            String[] mas = str.split(",");
            for (String l:mas) {
                hero.Strong.add(AllHero.get(HeroesName.indexOf(l)));
            }
            str = StrTool.Parse(lines.get(i),"(",")",1);
            mas = str.split(",");
            for (String l:mas) {
                hero.Weak.add(AllHero.get(HeroesName.indexOf(l)));
            }

        }*/
        Spinner spinner6 = (Spinner) findViewById(R.id.spinner6);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item);
        adapter.add("Кол. контр персонажей");
        adapter.add("Уровень преимущества");
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner6.setAdapter(adapter);
        spinner6.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent,
                                       View itemSelected, int selectedItemPosition, long selectedId) {
                MethodSortirovki = selectedItemPosition;
                updateCounterList();


            }
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });


        HeroesName = counterPick.getHeroesName();
        HeroesName.add(0,"");
        spinner = (Spinner) findViewById(R.id.spinner);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,HeroesName);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner2 = (Spinner) findViewById(R.id.spinner2);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,HeroesName);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(adapter);

        spinner3 = (Spinner) findViewById(R.id.spinner3);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,HeroesName);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner3.setAdapter(adapter);

        spinner4 = (Spinner) findViewById(R.id.spinner4);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,HeroesName);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner4.setAdapter(adapter);

        spinner5 = (Spinner) findViewById(R.id.spinner5);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,HeroesName);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner5.setAdapter(adapter);
        listView = (ListView) findViewById(R.id.listView);
        final Context context = this;
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent,
                                       View itemSelected, int selectedItemPosition, long selectedId) {

                updateCounterList();
            }
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent,
                                       View itemSelected, int selectedItemPosition, long selectedId) {

                updateCounterList();
            }
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        spinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent,
                                       View itemSelected, int selectedItemPosition, long selectedId) {

                updateCounterList();
            }
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        spinner4.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent,
                                       View itemSelected, int selectedItemPosition, long selectedId) {

                updateCounterList();
            }
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        spinner5.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent,
                                       View itemSelected, int selectedItemPosition, long selectedId) {

                updateCounterList();
            }
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });


// Вызываем адаптер


    }
    public void updateCounterList(){
        ArrayList<Hero> heros = new ArrayList<>();
        if (spinner.getSelectedItemPosition()>0) {
            heros.add(counterPick.getHero(spinner.getSelectedItemPosition()-1));
        }
        if (spinner2.getSelectedItemPosition()>0) {
            heros.add(counterPick.getHero(spinner2.getSelectedItemPosition()-1));
        }
        if (spinner3.getSelectedItemPosition()>0) {
            heros.add(counterPick.getHero(spinner3.getSelectedItemPosition()-1));
        }
        if (spinner4.getSelectedItemPosition()>0) {
            heros.add(counterPick.getHero(spinner4.getSelectedItemPosition()-1));
        }
        if (spinner5.getSelectedItemPosition()>0) {
            heros.add(counterPick.getHero(spinner5.getSelectedItemPosition()-1));
        }
                /*heros.add(AllHero.get(spinner.getSelectedItemPosition()));
                heros.add(AllHero.get(spinner2.getSelectedItemPosition()));
                heros.add(AllHero.get(spinner3.getSelectedItemPosition()));
                heros.add(AllHero.get(spinner4.getSelectedItemPosition()));
                heros.add(AllHero.get(spinner5.getSelectedItemPosition()));*/
        if (heros.size()>0) {
            ArrayList<String> strings = null;
            switch (MethodSortirovki) {
                case 0: {
                    strings = counterPick.CalculateCounterPick(heros);
                    break;
                }
                case 1: {
                    strings = counterPick.CalculateCounterPick2(heros);
                    break;
                }
            }
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, strings);

            listView.setAdapter(adapter);
        }
    }
    InetAddress getBroadcastAddress() throws IOException {
        WifiManager wifi = (WifiManager) getSystemService(Context.WIFI_SERVICE);
        DhcpInfo dhcp = wifi.getDhcpInfo();
        if(dhcp == null)
            return InetAddress.getByName("255.255.255.255");
        int broadcast = (dhcp.ipAddress & dhcp.netmask) | ~dhcp.netmask;
        byte[] quads = new byte[4];
        for (int k = 0; k < 4; k++)
            quads[k] = (byte) ((broadcast >> k * 8) & 0xFF);
        return InetAddress.getByAddress(quads);
    }
    public void SendBroadCastMSG(){
        new Thread(new Runnable() {
            @Override
            public void run() {
               // Log.d(TAG,"выполнен блок 1");
                try {
                 //   Log.d(TAG,"выполнeн блок 2.1");
                    DatagramSocket socket = new DatagramSocket(null);
                    socket.setReuseAddress(true);
                    socket.setBroadcast(true);
                    socket.bind(new InetSocketAddress(port + 1));
                 //   Log.d(TAG,"выполнин блок 2");
                    //if (socket.isConnected()) {
                     //   Log.d(TAG,"jkdfkjfhgkjdf");
                        String msg = "BroadCastFastDefinition:";
                        byte[] sendData = msg.getBytes();
                        DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, getBroadcastAddress(), port + 1);
                        socket.send(sendPacket);
                     //   Log.d(TAG,"выполнин блок 3");
                   // }
                }  catch (IOException e) {
                    System.out.println("Got an IOException: " + e.getMessage());
                }
            }
        }).start();
    }
    public void SearchTheServer(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                DatagramSocket socket = null;
                try {
                    socket = new DatagramSocket(null);
                    //socket.setReuseAddress(true);
                    socket.setBroadcast(true);
                    socket.bind(new InetSocketAddress(port+1));
                    String msg = "BroadCastFastDefinition:";
                    byte[] sendData = msg.getBytes();
                    DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, getBroadcastAddress(), port + 1);
                    socket.send(sendPacket);
                } catch (SocketException e) {
                    e.printStackTrace();
                }  catch (IOException e) {
                    System.out.println("Got an IOException: " + e.getMessage());
                }
                while (!socket.isClosed()) {
                    try {
                        byte[] buf = new byte[1024];
                        DatagramPacket packet = new DatagramPacket(buf, buf.length);
                        socket.receive(packet);
                        String s = new String(packet.getData(), 0, packet.getLength());
                        buf = new byte[1024];
                        packet = new DatagramPacket(buf, buf.length);
                        socket.receive(packet);
                        String s2 = new String(packet.getData(), 0, packet.getLength());
                        //Log.d(TAG,s);
                        //Log.d(TAG,s2);
                        String str = StringTool.parse(s,"",":");
                        if (str.equals("OK")){
                            String sIP = StringTool.parse(s,":","");
                            if (!sIP.equals("")){
                                ip = sIP;
                                socket.close();
                                ConnectSocket();
                            }
                        }
                        str = StringTool.parse(s2,"",":");
                        if (str.equals("OK")){
                            String sIP = StringTool.parse(s2,":","");
                            if (!sIP.equals("")){
                                ip = sIP;
                                socket.close();
                                ConnectSocket();
                            }
                        }

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                socket.close();
            }
        }).start();
        //SendBroadCastMSG();
    }
    public void ConnectSocket(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    InetAddress ipAddress = InetAddress.getByName(ip);
                    client = new Socket(ipAddress, port);
                    //client.setSoTimeout(300);
                    dataOutputStream = new DataOutputStream(client.getOutputStream());
                    dataInputStream = new DataInputStream(client.getInputStream());
                    if (client.isConnected()){
                        StartRead();
                        textView.post(new Runnable() {
                            @Override
                            public void run() {
                                textView.setText("Подключено");
                               // Resources res = getResources().getColor();
                                textView.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
                            }
                        });

                    }
                } catch (UnknownHostException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    System.out.println("Got an IOException: " + e.getMessage());
                }
            }
        }).start();
    }
    public void Button1Click(View view){
        //
        Button button = (Button) view;
        if (button.getText().equals("Подключиться")) {
            ip = editText.getText().toString();
            //Log.d(TAG,ip);
            if (!ip.equals("")) {
                ConnectSocket();
            } else {
                SearchTheServer();
            }
            button.setText("Отключиться");
        } else {
            button.setText("Подключиться");
            if ((client!=null)&&(!client.isClosed())){
                try {
                    client.close();
                    textView.post(new Runnable() {
                        @Override
                        public void run() {
                            textView.setText("Не подключено");
                            // Resources res = getResources().getColor();
                            textView.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
                        }
                    });
                } catch (IOException e) {
                    System.out.println("Got an IOException: " + e.getMessage());
                }
            }
        }

    }
    public void Button4Click(View view) {

    }
    public void StartRead(){
        //
        isReading = true;
        final RadioButton radioButton = (RadioButton)findViewById(R.id.radioButton);
        final RadioButton radioButton2 = (RadioButton)findViewById(R.id.radioButton2);
        new Thread(new Runnable() {
            @Override
            public void run() {
                //BufferedReader input = null;
                DataInputStream input = null;
                try {
                    //input = new BufferedReader(new InputStreamReader(client.getInputStream()));
                    input = new DataInputStream(client.getInputStream());
                } catch (IOException e) {

                    e.printStackTrace();

                }

                while (!client.isClosed()) {
                    String line;
                    try {
                        //   line = input.readLine();//dataInputStream.readUTF();
                        //if ((line = input.readUTF()/*.readLine()*/) != null) {
                        if ((line = dataInputStream.readUTF())!=null){
                            // if (dataInputStream.available()>0){
                            //   line = dataInputStream.readUTF();
                            //Log.d(TAG,"Вход сокета "+line);
                            String[] mas = new String[5];
                            if (radioButton.isChecked()) {
                                String s = StringTool.parse(line, "", ":");
                                mas = s.split(";");
                                if (mas.length==0){
                                    mas = new String[5];
                                }
                            }
                            if (radioButton2.isChecked()) {
                                String s = StringTool.parse(line, ":", "");
                                mas = s.split(";");
                                if (mas.length==0){
                                    mas = new String[5];
                                }
                            }

                            int po = HeroesName.indexOf(mas[0]);
                            if (po == -1) {
                                po = 0;
                            }
                            {final int pof = po;
                                spinner.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        spinner.setSelection(pof);
                                    }
                                });}


                            po = HeroesName.indexOf(mas[1]);
                            if (po == -1) {
                                po = 0;
                            }
                            {final int pof = po;
                                spinner2.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        spinner2.setSelection(pof);
                                    }
                                });}

                            po = HeroesName.indexOf(mas[2]);
                            if (po == -1) {
                                po = 0;
                            }
                            {final int pof = po;
                                spinner3.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        spinner3.setSelection(pof);
                                    }
                                });}

                            po = HeroesName.indexOf(mas[3]);
                            if (po == -1) {
                                po = 0;
                            }
                            {final int pof = po;
                                spinner4.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        spinner4.setSelection(pof);
                                    }
                                });}
                            po = HeroesName.indexOf(mas[4]);
                            if (po == -1) {
                                po = 0;
                            }
                            {final int pof = po;
                                spinner5.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        spinner5.setSelection(pof);
                                    }
                                });}


                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }

   /* public static ArrayList<String> CalculateCounterPick(ArrayList<Hero> Heroes){
        class Her{
            public String Name;
            public int Count;
            public Her(String name,int count)
            {
                Name = name;
                Count = count;
            }
        }
        ArrayList<String> Result = new ArrayList<>();
        HashMap<String,Integer> Re = new HashMap<>();
        for (Hero h:Heroes){
            for (Hero h2:h.Weak){
                if (Re.containsKey(h2.Name)) {
                    Re.put(h2.Name, Re.get(h2.Name) + 1);
                } else {
                    Re.put(h2.Name, 1);
                }
            }

        }
        for (Hero h:Heroes){
            for (Hero h2:h.Strong){
                Re.put(h2.Name,0);
            }
            Re.put(h.Name,0);
        }

        ArrayList<Her> ListHer = new ArrayList<>();
        for (Map.Entry entry : Re.entrySet()) {
            *//*System.out.println("Key: " + entry.getKey() + " Value: "
                    + entry.getValue());*//*
            if ((Integer)entry.getValue() > 0) {
                ListHer.add(new Her((String) entry.getKey(), (Integer)entry.getValue()));
            }
        }
        Collections.sort(ListHer, new Comparator<Her>() {
            @Override
            public int compare(Her o1, Her o2) {
                return o2.Count-o1.Count;
            }
        });
        for (Her h:ListHer){
            Result.add(h.Name);
        }
        return Result;
    }*/
    @Override
    protected void onDestroy() {
        super.onDestroy();
        isReading = false;
        try {
            client.close();
        } catch (IOException e) {
            System.out.println("Got an IOException: " + e.getMessage());
        }
    }
}
