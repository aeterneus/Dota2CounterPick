package com.kuldiegor.dota2counterpick;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Date;

public class Main2Activity extends AppCompatActivity {
    DownloadStatistics downloadStatistics;
    TextView textView1;
    ProgressBar progressBar1;
    final String FILENAME = "filestatistics";
    private SharedPreferences mSettings;
    public static final String APP_PREFERENCES = "mysettings";
    public static final String APP_PREFERENCES_UPDATE = "lastupdate";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        textView1 = (TextView)findViewById(R.id.textView3);
        progressBar1 = (ProgressBar)findViewById(R.id.progressBar);
        mSettings = getSharedPreferences(APP_PREFERENCES, Context.MODE_PRIVATE);

    }
    public void writeFile(ArrayList<String> strings) {
        try {
            // отрываем поток для записи
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(
                    openFileOutput(FILENAME, MODE_PRIVATE)));
            // пишем данные
            for (int i=0;i<strings.size();i++){
                bw.write(strings.get(i)+"\n");
            }
            //bw.write("Содержимое файла");
            // закрываем поток
            bw.close();
            // Log.d(LOG_TAG, "Файл записан");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void Button1_1Click(View view){
        new Thread(new Runnable() {
            @Override
            public void run() {
                InputStream is = getResources().openRawResource(R.raw.listurlshero);
                BufferedReader reader = null;
                ArrayList<String> lines = new ArrayList<String>();
                try {
                    reader = new BufferedReader(
                            new InputStreamReader(is));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        lines.add(line);
                    }
                }
                catch (Exception e) {
                }
                downloadStatistics = new DownloadStatistics(lines,textView1,progressBar1);
                writeFile(downloadStatistics.data);
                SharedPreferences.Editor editor = mSettings.edit();
                editor.putLong(APP_PREFERENCES_UPDATE, (new Date()).getTime());
                editor.apply();
                UpdateDialogFragment updateDialogFragment = new  UpdateDialogFragment();
                updateDialogFragment.show(getSupportFragmentManager(), "dialog");
            }
        }).start();
    }
}
